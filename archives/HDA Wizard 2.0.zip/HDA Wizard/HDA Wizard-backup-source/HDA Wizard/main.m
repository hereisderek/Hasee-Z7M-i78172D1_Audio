//
//  main.m
//  HDA Wizard
//
//  Created by Janek on 26.08.2011.
//  Copyright 2011 janek202. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
