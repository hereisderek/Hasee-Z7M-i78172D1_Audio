//
//  HDA_WizardAppDelegate.m
//  HDA Wizard
//
//  Created by Janek on 26.08.2011.
//  Copyright 2011 janek202. All rights reserved.
//
/*
 This file is part of HDA Wizard.
 
 HDA Wizard is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.
 
 HDA Wizard is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Foobar; if not, write to the Free Software
 Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#import "HDA_WizardAppDelegate.h"

@implementation HDA_WizardAppDelegate

@synthesize window;
@synthesize layoutpath;
@synthesize platformpath;
@synthesize browseLayout;
@synthesize browsePlatform;
@synthesize checkLayout;
@synthesize checkPlatforms;
@synthesize checkBinpatch;
@synthesize binpatchSelect;
@synthesize customBinpatch;
@synthesize patchButton;
@synthesize restoreButton;
@synthesize checkBackup;
@synthesize circle;
@synthesize CustomBinpatchData;
@synthesize infopath;
@synthesize browseInfo;
@synthesize checkInfo;
@synthesize menu_newver;

#define _donate_link        @"http://exampleserver.com/donate.html"
#define _patches_link       @"http://exampleserver.com/patches.plist"
#define _versioninfo_link   @"http://exampleserver.com/versioninfo.plist"

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    
    void (^checkBlock)(void);
    checkBlock = ^{
        NSDictionary *updateinfo = [NSDictionary dictionaryWithContentsOfURL:[NSURL URLWithString:_versioninfo_link]];
        if (updateinfo != nil)
        {
            if ([[[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleVersion"] isNotEqualTo: [updateinfo objectForKey:@"Version"]])
            {
                [menu_newver setTitle:[@"New version: " stringByAppendingString:[updateinfo objectForKey:@"Version"]]];
                [menu_newver setHidden:NO];
                link= [[updateinfo objectForKey:@"Link" ]copy];
            }
        }
        
    };
    
    if ([[[NSBundle mainBundle] objectForInfoDictionaryKey:@"AppUpdates"] boolValue])
    {
        dispatch_queue_t queue = dispatch_get_global_queue(0,0);
        dispatch_async(queue,checkBlock);
        dispatch_release(queue);
    }
    
    [binpatchSelect removeAllItems];
    patches = [[NSMutableArray alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"patches" ofType:@"plist"]];
    for (int i=0; i<[patches count]; i++)
        [binpatchSelect addItemWithTitle: [[patches objectAtIndex:i] objectForKey:@"CodecName"]] ;
    
    
    
}


- (IBAction)SelectLayout:(id)sender 
{
    NSOpenPanel *openplayout = [NSOpenPanel openPanel];
    [openplayout setAllowedFileTypes:[NSArray arrayWithObject:@"zlib"]];
    [openplayout beginSheetForDirectory:nil
                                 file:nil
                                types:[NSArray arrayWithObject:@"zlib"]
                       modalForWindow:window
                        modalDelegate:self
                       didEndSelector:@selector(Openlxml:
                                                returnCode:
                                                contextInfo:)
                          contextInfo:nil];
}

-(void) Openlxml:(NSOpenPanel*)sheet
      returnCode:(int)returnCode
     contextInfo:(void*)contextInfo
{
    if (returnCode !=NSOKButton)
        return;
    [layoutpath setStringValue:[sheet filename]];
    [checkLayout setState:1];
    
}

- (IBAction)SelectPlatforms:(id)sender 
{
    NSOpenPanel *openplatforms = [NSOpenPanel openPanel];
    [openplatforms setAllowedFileTypes:[NSArray arrayWithObject:@"zlib"]];
    [openplatforms beginSheetForDirectory:nil
                                   file:nil
                                  types:[NSArray arrayWithObject:@"zlib"]
                         modalForWindow:window
                          modalDelegate:self
                         didEndSelector:@selector(Openpxml:
                                                  returnCode:
                                                  contextInfo:)
                            contextInfo:nil];
}

-(void) Openpxml:(NSOpenPanel*)sheet
      returnCode:(int)returnCode
     contextInfo:(void*)contextInfo
{
    if (returnCode !=NSOKButton)
        return;
    [platformpath setStringValue:[sheet filename]];
    [checkPlatforms setState:1];
    
}


- (IBAction)SelectInfo:(id)sender 
{
    
    NSOpenPanel *openinfo = [NSOpenPanel openPanel];
    [openinfo setAllowedFileTypes:[NSArray arrayWithObject:@"plist"]];
    [openinfo beginSheetForDirectory:nil
                                     file:nil
                                    types:[NSArray arrayWithObject:@"plist"]
                           modalForWindow:window
                            modalDelegate:self
                           didEndSelector:@selector(Openiplist:
                                                    returnCode:
                                                    contextInfo:)
                              contextInfo:nil];
}

-(void) Openiplist:(NSOpenPanel*)sheet
      returnCode:(int)returnCode
     contextInfo:(void*)contextInfo
{
    if (returnCode !=NSOKButton)
        return;
    [infopath setStringValue:[sheet filename]];
    [checkInfo setState:1];
    
}



- (IBAction)Patch:(id)sender
{
    if (![[BLAuthentication sharedInstance] isAuthenticated:@"root"])
        [[BLAuthentication sharedInstance] authenticate:@"root"];
    
    if (![[BLAuthentication sharedInstance] isAuthenticated:@"root"])
        return;
    [circle startAnimation:self];
    //Backup
    if ([checkBackup state])
    [[NSFileManager defaultManager] copyItemAtPath:@"/System/Library/Extensions/AppleHDA.kext" toPath:[NSHomeDirectory() stringByAppendingString:@"/Desktop/AppleHDA.kext"] error:nil];
    
  //  return;
    
    //Layout
    if ([checkLayout state])
    {
        if ([[NSFileManager defaultManager] fileExistsAtPath: [layoutpath stringValue]])
            [[BLAuthentication sharedInstance] executeCommandSynced:_cp withArgs: [NSArray arrayWithObjects:@"-f",[layoutpath stringValue],@"/System/Library/Extensions/AppleHDA.kext/Contents/Resources", nil]];
    }
    
    //Platforms
    if ([checkPlatforms state])
    {
        if ([[NSFileManager defaultManager] fileExistsAtPath: [platformpath stringValue]])
            [[BLAuthentication sharedInstance] executeCommandSynced:_cp withArgs: [NSArray arrayWithObjects:@"-f",[platformpath stringValue],@"/System/Library/Extensions/AppleHDA.kext/Contents/Resources", nil]];
    }
    
    //Info
    if ([checkInfo state])
    {
        if ([[NSFileManager defaultManager] fileExistsAtPath: [infopath stringValue]])
            [[BLAuthentication sharedInstance] executeCommandSynced:_cp withArgs: [NSArray arrayWithObjects:@"-f",[infopath stringValue],@"/System/Library/Extensions/AppleHDA.kext/Contents/PlugIns/AppleHDAHardwareConfigDriver.kext/Contents", nil]];
    }
    
    
    //Binpatch
    //sudo perl -pi -e 's|\x8b\x19\xd4\x11|\x88\x08\xec\x10|g' /System/Library/Extensions/AppleHDA.kext/Contents/MacOS/AppleHDA
    if ([checkBinpatch state])
    {
        NSString *path= [NSHomeDirectory() stringByAppendingString:@"/AppleHDA"];
        [[NSFileManager defaultManager] removeItemAtPath: path error:nil];
        [[NSFileManager defaultManager] copyItemAtPath:@"/System/Library/Extensions/AppleHDA.kext/Contents/MacOS/AppleHDA" toPath: path error:nil];
        
        if (![binpatchSelect isHidden])
            system ([[NSString stringWithFormat:@"%@%@%@%@",@"perl -pi -e ",[[patches objectAtIndex: [binpatchSelect indexOfSelectedItem]] objectForKey:@"Patch"],@" ",path] UTF8String]);
        else
            system ([[NSString stringWithFormat:@"%@%@%@%@",@"perl -pi -e ",[CustomBinpatchData stringValue],@" ",path] UTF8String]);
        
        
        [[BLAuthentication sharedInstance] executeCommandSynced:_cp withArgs: [NSArray arrayWithObjects:@"-f",path,@"/System/Library/Extensions/AppleHDA.kext/Contents/MacOS", nil]];
        
        [[NSFileManager defaultManager] removeItemAtPath: path error:nil];
   }
    
    
    [[BLAuthentication sharedInstance] executeCommandSynced:_chown withArgs: [NSArray arrayWithObjects: @"-R", @"0:0",@"/System/Library/Extensions/AppleHDA.kext", nil]];
    
    [[BLAuthentication sharedInstance] executeCommandSynced:_chmod withArgs: [NSArray arrayWithObjects:@"-R", @"755",@"/System/Library/Extensions/AppleHDA.kext", nil]];

    [[BLAuthentication sharedInstance] executeCommandSynced:_touch withArgs: [NSArray arrayWithObject:@"/System/Library/Extensions"]];
    
    [[BLAuthentication sharedInstance] executeCommandSynced:_kextcache withArgs: [NSArray arrayWithObject:@"-system-caches"]];
        
    [[BLAuthentication sharedInstance] executeCommandSynced:_kextcache withArgs: [NSArray arrayWithObject:@"-system-prelinked-kernel"]];

    [circle stopAnimation:self];
    [[IconAlert defaultinst] ShowInfoMsg:@"AppleHDA patching finished. Please reboot your system." DestWindow:window];
}

- (IBAction)Restore:(id)sender 
{
    NSOpenPanel *openhda = [NSOpenPanel openPanel];
    [openhda setAllowedFileTypes:[NSArray arrayWithObject:@"kext"]];
    [openhda beginSheetForDirectory:nil
                                   file:nil
                                  types:[NSArray arrayWithObject:@"kext"]
                         modalForWindow:window
                          modalDelegate:self
                         didEndSelector:@selector(restorehda:
                                                  returnCode:
                                                  contextInfo:)
                            contextInfo:nil];
}

-(void) restorehda:(NSOpenPanel*)sheet
      returnCode:(int)returnCode
     contextInfo:(void*)contextInfo
{
    if (returnCode !=NSOKButton)
        return;
    
  //  NSLog([[sheet filename] lastPathComponent]);
    if ([[[sheet filename] lastPathComponent]isNotEqualTo:@"AppleHDA.kext"])
        return;
    
    if (![[BLAuthentication sharedInstance] isAuthenticated:@"root"])
        [[BLAuthentication sharedInstance] authenticate:@"root"];
    
    if (![[BLAuthentication sharedInstance] isAuthenticated:@"root"])
        return;
    [circle startAnimation:self];
    if ([[NSFileManager defaultManager] fileExistsAtPath: @"/System/Library/Extensions/AppleHDA.kext"])
    {
        [[BLAuthentication sharedInstance] executeCommandSynced:_rm withArgs:([NSArray arrayWithObjects:@"-Rf", @"/System/Library/Extensions/AppleHDA.kext", nil])];
    }
    
    [[BLAuthentication sharedInstance] executeCommandSynced:_cp withArgs:([NSArray arrayWithObjects:@"-R",[sheet filename],@"/System/Library/Extensions", nil])];
    
    [[BLAuthentication sharedInstance] executeCommandSynced:_chown withArgs: [NSArray arrayWithObjects: @"-R", @"0:0",@"/System/Library/Extensions/AppleHDA.kext", nil]];
    
    [[BLAuthentication sharedInstance] executeCommandSynced:_chmod withArgs: [NSArray arrayWithObjects:@"-R", @"755",@"/System/Library/Extensions/AppleHDA.kext", nil]];
    
    [[BLAuthentication sharedInstance] executeCommandSynced:_touch withArgs: [NSArray arrayWithObject:@"/System/Library/Extensions"]];
    
    [[BLAuthentication sharedInstance] executeCommandSynced:_kextcache withArgs: [NSArray arrayWithObject:@"-system-caches"]];
    
    [[BLAuthentication sharedInstance] executeCommandSynced:_kextcache withArgs: [NSArray arrayWithObject:@"-system-prelinked-kernel"]];
    
    
    // update system kext caches for osx 10.10 :
    
    [[BLAuthentication sharedInstance] executeCommandSynced:_kextcache withArgs: [NSArray arrayWithObject:@"-prelinked-kernel"]];
    
   
    [circle stopAnimation:self];
    [[IconAlert defaultinst] ShowInfoMsg:@"AppleHDA kext patched and restored. Please reboot your system." DestWindow:nil];
}

- (IBAction)SetCustomBinpath:(id)sender 
{
    if ([binpatchSelect isHidden])
    {
        [binpatchSelect setHidden:NO];
        [CustomBinpatchData setHidden: YES];
        [customBinpatch setTitle:@"Custom"];
    }
    else
    {
        [binpatchSelect setHidden:YES];
        [CustomBinpatchData setHidden: NO];
        [customBinpatch setTitle:@"Defaults"];
    }

}
    


//// Drop plikow

- (void)filesDragged:(filesdrop*)sender
{
    NSMutableArray * files = [[NSMutableArray alloc] initWithArray:[sender filenames]];
    
    for (int i=0; i<[files count]; i++) 
    {
        if ([[files objectAtIndex:i] rangeOfString:@"layout" options:NSCaseInsensitiveSearch].location != NSNotFound)
        {
            [layoutpath setStringValue:[files objectAtIndex:i]];
            [checkLayout setState:1];
        }
        
        if ([[files objectAtIndex:i] rangeOfString:@"Info" options:NSCaseInsensitiveSearch].location != NSNotFound)
        {
            [infopath setStringValue:[files objectAtIndex:i]];
            [checkInfo setState:1];
        }
        
        if ([[files objectAtIndex:i] rangeOfString:@"Platforms.xml.zlib" options:NSCaseInsensitiveSearch].location != NSNotFound)
        {
            [platformpath setStringValue:[files objectAtIndex:i]];
            [checkPlatforms setState:1];
        }
    }
    [files release];
}


- (IBAction)binpatchListUpdate:(id)sender 
{
    [circle startAnimation:self];
    NSArray *downloaded = [NSArray arrayWithContentsOfURL:[NSURL URLWithString:_patches_link]];
    if (downloaded==nil)
    {
        [[IconAlert defaultinst] ShowErrorMsg:@"Couldn't download file.\nCheck your internet connection, and try again later." DestWindow:window];
        [circle stopAnimation:self];
        return;
    }
    [binpatchSelect removeAllItems];
    [patches removeAllObjects];
    [patches addObjectsFromArray: downloaded];
    for (int i=0; i<[patches count]; i++)
        [binpatchSelect addItemWithTitle: [[patches objectAtIndex:i] objectForKey:@"CodecName"]] ;
    
    [patches writeToFile: [[NSBundle mainBundle] pathForResource:@"patches" ofType:@"plist"] atomically:YES];
    [circle stopAnimation:self];
}


- (IBAction)MakeDonation:(id)sender 
{
    [[NSWorkspace sharedWorkspace] openURL:[NSURL URLWithString: _donate_link]];
}

- (IBAction)DownloadNewVersion:(id)sender 
{
    [[NSWorkspace sharedWorkspace] openURL:[NSURL URLWithString: link]];
}


- (IBAction)BinpatchSelected:(id)sender 
{
    [checkBinpatch setState:1];
}


- (BOOL) applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApplication
{
    return YES;
} 

@end
