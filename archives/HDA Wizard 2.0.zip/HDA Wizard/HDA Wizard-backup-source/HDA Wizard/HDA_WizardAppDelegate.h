//
//  HDA_WizardAppDelegate.h
//  HDA Wizard
//
//  Created by Janek on 26.08.2011.
//  Copyright 2011 janek202. All rights reserved.
/*
 This file is part of HDA Wizard.
 
 HDA Wizard is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.
 
 HDA Wizard is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Foobar; if not, write to the Free Software
 Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#import <Cocoa/Cocoa.h>
#import "BLAuthentication.h"
#import "ClIconAlert.h"

#define _cp @"/bin/cp"
#define _rm @"/bin/rm"
#define _chmod @"/bin/chmod"
#define _chown @"/usr/sbin/chown"
#define _touch @"/usr/bin/touch"
#define _kextcache @"/usr/sbin/kextcache"
//#define _perl @"/usr/bin/perl"

@class filesdrop;

@interface HDA_WizardAppDelegate : NSObject <NSApplicationDelegate> {
    NSWindow *window;
    NSTextField *layoutpath;
    NSTextField *platformpath;
    NSButton *browseLayout;
    NSButton *browsePlatform;
    NSButton *checkLayout;
    NSButton *checkPlatforms;
    NSButton *checkBinpatch;
    NSPopUpButton *binpatchSelect;
    NSButton *customBinpatch;
    NSButton *patchButton;
    NSButton *restoreButton;
    NSButton *checkBackup;
    NSProgressIndicator *circle;
    NSTextField *CustomBinpatchData;
    NSTextField *infopath;
    NSButton *browseInfo;
    NSButton *checkInfo;
    NSMenuItem *menu_newver;
    
    NSString *link;
    
    NSMutableArray *patches;
}

@property (assign) IBOutlet NSWindow *window;
@property (assign) IBOutlet NSTextField *layoutpath;
@property (assign) IBOutlet NSTextField *platformpath;
@property (assign) IBOutlet NSButton *browseLayout;
@property (assign) IBOutlet NSButton *browsePlatform;
@property (assign) IBOutlet NSButton *checkLayout;
@property (assign) IBOutlet NSButton *checkPlatforms;
@property (assign) IBOutlet NSButton *checkBinpatch;
@property (assign) IBOutlet NSPopUpButton *binpatchSelect;
@property (assign) IBOutlet NSButton *customBinpatch;
@property (assign) IBOutlet NSButton *patchButton;
@property (assign) IBOutlet NSButton *restoreButton;
@property (assign) IBOutlet NSButton *checkBackup;
@property (assign) IBOutlet NSProgressIndicator *circle;
@property (assign) IBOutlet NSTextField *CustomBinpatchData;
@property (assign) IBOutlet NSTextField *infopath;
@property (assign) IBOutlet NSButton *browseInfo;
@property (assign) IBOutlet NSButton *checkInfo;
@property (assign) IBOutlet NSMenuItem *menu_newver;


- (void)filesDragged:(filesdrop*)sender;
@end
